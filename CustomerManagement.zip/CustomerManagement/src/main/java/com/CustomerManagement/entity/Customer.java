package com.CustomerManagement.entity;
import java.util.*;
import java.util.List;

import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "customer_order")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="firstname")
	private String firstname;
	
	@Column(name="Lastname")
	private String lastname;
	
	
	@Column(name="Email",unique=true)
	private String email;
	
	@Column(name="MobileNo")
	private Long mobileno;
	
	@OneToMany(mappedBy = "customer")
    private List<Order> orders = new ArrayList<>();

}
