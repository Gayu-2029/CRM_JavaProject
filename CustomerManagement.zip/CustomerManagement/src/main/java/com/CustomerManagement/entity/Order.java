package com.CustomerManagement.entity;
import java.util.*;

import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "order_product")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Order 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="Quantity")
	private Long quantity;
	
	@Column(name="TotalPrice")
	private double total_price;
	
	@ManyToMany
    @JoinTable(
        name = "order_product",
        joinColumns = @JoinColumn(name = "order_id"),
        inverseJoinColumns = @JoinColumn(name = "product_id")
    		  )
    private List<Product> products = new ArrayList<>();
	
	@ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;
    
}
