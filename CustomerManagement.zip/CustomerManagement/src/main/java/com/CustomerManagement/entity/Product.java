package com.CustomerManagement.entity;
import java.util.*;

import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "product_customer")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="ProductName")
	private String productname;
	
	@Column(name="Price")
	private double price;
	
	 @ManyToMany(mappedBy = "products")
	    private List<Order> orders = new ArrayList<>();
	 

}
